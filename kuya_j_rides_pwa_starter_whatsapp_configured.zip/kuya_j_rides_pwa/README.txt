KUYA J RIDES — FREE STARTER PWA
================================

WHAT THIS IS
- Mobile-friendly customer ordering app prototype.
- Designed to work on modern Android and iPhone browsers.
- Customers choose a service and fill in their delivery details.
- The form opens WhatsApp with a pre-filled order message.
- It is a single-rider/manual-confirmation MVP.

IMPORTANT LIMITATIONS
- No server/database, customer accounts, live GPS, automated dispatch, payment processing, or order history.
- A WhatsApp message is not a confirmed booking until the rider replies and confirms the fee/availability.
- Never publish with the placeholder WhatsApp number still in config.js.
- Do not promise delivery of prohibited or unsafe items.
- Treat customer names, phone numbers, and addresses as private information.

STEP 1 — SET YOUR WHATSAPP NUMBER
1. Open config.js in a text editor.
2. Replace REPLACE_WITH_YOUR_NUMBER with your number in international digits format.
   Example: 0917 123 4567 becomes 639171234567.
3. Save the file.
4. Test the request button on your own phone before sharing the app.

STEP 2 — HOST IT FOR FREE
One free static-hosting option is GitHub Pages:
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. kuya-j-rides.
3. Upload all files from this folder to the repository root.
4. In repository Settings, open Pages.
5. Select deployment from the main branch/root and save.
6. Wait for GitHub Pages to provide your HTTPS website address.
Hosting provider interfaces and free-plan terms may change; check the current settings shown by the provider.

STEP 3 — INSTALL ON ANDROID
1. Open the published HTTPS link in Chrome.
2. Open the browser menu and choose Install app or Add to Home screen if offered.

STEP 4 — ADD TO IPHONE HOME SCREEN
1. Open the published HTTPS link in Safari.
2. Tap Share.
3. Choose Add to Home Screen.
4. Tap Add.

STEP 5 — TEST SAFELY
- Submit a test request to your own WhatsApp number first.
- Check that service, pickup, destination, contact number and request details are correct.
- Confirm your delivery fee, coverage, hours, cash handling, cancellation policy and rider availability before accepting public orders.

NEXT FEATURES AFTER TESTING
1. Admin/order database so orders can be tracked.
2. Rider view and status updates.
3. Customer confirmation and notifications.
4. Maps/GPS and distance-based pricing.
5. Business compliance and privacy notice before scaling.

This is starter code, not a guarantee of commercial readiness. A public launch needs testing, a privacy notice, appropriate business/legal checks, and a reliable process for handling customer information.

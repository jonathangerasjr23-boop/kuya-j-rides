const serviceButtons = [...document.querySelectorAll(".service")];
let selectedService = "Pabili / Errands";
serviceButtons.forEach(button => {
  button.addEventListener("click", () => {
    serviceButtons.forEach(item => item.classList.remove("selected"));
    button.classList.add("selected");
    selectedService = button.dataset.service;
  });
});
document.getElementById("orderForm").addEventListener("submit", event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const get = key => String(form.get(key) || "").trim();
  const config = window.KUYA_J_CONFIG || {};
  const number = String(config.whatsappNumber || "").replace(/\D/g, "");
  const details = [
    `NEW DELIVERY REQUEST — ${config.businessName || "Kuya J Rides"}`,
    `Service: ${selectedService}`,
    `Customer: ${get("name")}`,
    `Customer mobile: ${get("phone")}`,
    `Pickup/store: ${get("pickup")}`,
    `Delivery address: ${get("dropoff")}`,
    `Order/parcel details: ${get("details")}`,
    `Item budget: ${get("budget") ? "₱" + get("budget") : "Not specified"}`,
    `Payment preference: ${get("payment")}`,
    `Timing: ${get("when")}`,
    "",
    "Please confirm availability and delivery fee before accepting this request."
  ].join("\n");
  if (!number || number.includes("REPLACE")) {
    alert("Buddy, the app still needs your WhatsApp number. Set whatsappNumber in config.js before taking real requests.");
    return;
  }
  window.open(`https://wa.me/${number}?text=${encodeURIComponent(details)}`, "_blank", "noopener,noreferrer");
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
}
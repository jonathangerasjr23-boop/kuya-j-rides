/*
  Kuya J Rides WhatsApp order contact.
  International format, digits only: 639631199681
*/
window.KUYA_J_CONFIG = {
  whatsappNumber: "639631199681",
  businessName: "Kuya J Rides",
  serviceArea: "Tagbilaran City, Bohol"
};
